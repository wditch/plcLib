plcLib
======

A simple C/C++ code library to allow PLC-style programming of Arduino-based systems and compatibles.

Please see the [Wiki](https://github.com/wditch/plcLib/wiki) for documentation and download links.
